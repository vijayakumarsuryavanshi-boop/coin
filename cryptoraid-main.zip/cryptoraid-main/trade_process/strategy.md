## Knowledge base
- For a bull market basic 2 paddle strategy works fine
- To separate previously purchased target symbol, NEVER EVER auto increase sell amount while in the process.
- All set amount which seems like an okay trade to others. Anything eye catching will cause unnecessary attention
- For a bear market
    - minimise the profit, sell as quickly as possible so that we can buy at more dip.
    - increase wait time for the better dip

- single code to adjust hyperparameters as bull vs bear market could be difficult.
- a queue needs to be maintained for a trend calculation. length of the queue ans interval for samples are also hyperparameters.
